<?php
$_lang['setting_dbadmin.debug'] = 'Debug';
$_lang['setting_dbadmin.debug_desc'] = 'Log debug information in the MODX error log.';
