<?php
$_lang['setting_dbadmin.debug'] = 'Debug';
$_lang['setting_dbadmin.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
