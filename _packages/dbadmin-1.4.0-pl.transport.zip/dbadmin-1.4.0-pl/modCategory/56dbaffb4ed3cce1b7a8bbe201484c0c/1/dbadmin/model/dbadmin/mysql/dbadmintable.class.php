<?php
require_once (dirname(dirname(__FILE__)) . '/dbadmintable.class.php');
class dbAdminTable_mysql extends dbAdminTable {}