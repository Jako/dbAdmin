<?php
/**
 * dbAdmin
 *
 * Copyright 2015-2023 by Sergey Shlokov <sergant210@bk.ru>
 *
 * @package dbadmin
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * Class dbAdmin
 */
class dbAdmin extends \Sergant210\dbAdmin\dbAdmin
{
}
